// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2025.1.1 (64-bit)
// Tool Version Limit: 2025.05
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2025 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
#ifndef __linux__

#include "xstatus.h"
#ifdef SDT
#include "xparameters.h"
#endif
#include "xnaive_dot.h"

extern XNaive_dot_Config XNaive_dot_ConfigTable[];

#ifdef SDT
XNaive_dot_Config *XNaive_dot_LookupConfig(UINTPTR BaseAddress) {
	XNaive_dot_Config *ConfigPtr = NULL;

	int Index;

	for (Index = (u32)0x0; XNaive_dot_ConfigTable[Index].Name != NULL; Index++) {
		if (!BaseAddress || XNaive_dot_ConfigTable[Index].Ctrl_bus_BaseAddress == BaseAddress) {
			ConfigPtr = &XNaive_dot_ConfigTable[Index];
			break;
		}
	}

	return ConfigPtr;
}

int XNaive_dot_Initialize(XNaive_dot *InstancePtr, UINTPTR BaseAddress) {
	XNaive_dot_Config *ConfigPtr;

	Xil_AssertNonvoid(InstancePtr != NULL);

	ConfigPtr = XNaive_dot_LookupConfig(BaseAddress);
	if (ConfigPtr == NULL) {
		InstancePtr->IsReady = 0;
		return (XST_DEVICE_NOT_FOUND);
	}

	return XNaive_dot_CfgInitialize(InstancePtr, ConfigPtr);
}
#else
XNaive_dot_Config *XNaive_dot_LookupConfig(u16 DeviceId) {
	XNaive_dot_Config *ConfigPtr = NULL;

	int Index;

	for (Index = 0; Index < XPAR_XNAIVE_DOT_NUM_INSTANCES; Index++) {
		if (XNaive_dot_ConfigTable[Index].DeviceId == DeviceId) {
			ConfigPtr = &XNaive_dot_ConfigTable[Index];
			break;
		}
	}

	return ConfigPtr;
}

int XNaive_dot_Initialize(XNaive_dot *InstancePtr, u16 DeviceId) {
	XNaive_dot_Config *ConfigPtr;

	Xil_AssertNonvoid(InstancePtr != NULL);

	ConfigPtr = XNaive_dot_LookupConfig(DeviceId);
	if (ConfigPtr == NULL) {
		InstancePtr->IsReady = 0;
		return (XST_DEVICE_NOT_FOUND);
	}

	return XNaive_dot_CfgInitialize(InstancePtr, ConfigPtr);
}
#endif

#endif

