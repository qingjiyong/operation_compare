// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2025.1.1 (64-bit)
// Tool Version Limit: 2025.05
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2025 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
#ifndef XNAIVE_DOT_H
#define XNAIVE_DOT_H

#ifdef __cplusplus
extern "C" {
#endif

/***************************** Include Files *********************************/
#ifndef __linux__
#include "xil_types.h"
#include "xil_assert.h"
#include "xstatus.h"
#include "xil_io.h"
#else
#include <stdint.h>
#include <assert.h>
#include <dirent.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <unistd.h>
#include <stddef.h>
#endif
#include "xnaive_dot_hw.h"

/**************************** Type Definitions ******************************/
#ifdef __linux__
typedef uint8_t u8;
typedef uint16_t u16;
typedef uint32_t u32;
typedef uint64_t u64;
#else
typedef struct {
#ifdef SDT
    char *Name;
#else
    u16 DeviceId;
#endif
    u64 Ctrl_bus_BaseAddress;
    u64 Control_BaseAddress;
} XNaive_dot_Config;
#endif

typedef struct {
    u64 Ctrl_bus_BaseAddress;
    u64 Control_BaseAddress;
    u32 IsReady;
} XNaive_dot;

typedef u32 word_type;

/***************** Macros (Inline Functions) Definitions *********************/
#ifndef __linux__
#define XNaive_dot_WriteReg(BaseAddress, RegOffset, Data) \
    Xil_Out32((BaseAddress) + (RegOffset), (u32)(Data))
#define XNaive_dot_ReadReg(BaseAddress, RegOffset) \
    Xil_In32((BaseAddress) + (RegOffset))
#else
#define XNaive_dot_WriteReg(BaseAddress, RegOffset, Data) \
    *(volatile u32*)((BaseAddress) + (RegOffset)) = (u32)(Data)
#define XNaive_dot_ReadReg(BaseAddress, RegOffset) \
    *(volatile u32*)((BaseAddress) + (RegOffset))

#define Xil_AssertVoid(expr)    assert(expr)
#define Xil_AssertNonvoid(expr) assert(expr)

#define XST_SUCCESS             0
#define XST_DEVICE_NOT_FOUND    2
#define XST_OPEN_DEVICE_FAILED  3
#define XIL_COMPONENT_IS_READY  1
#endif

/************************** Function Prototypes *****************************/
#ifndef __linux__
#ifdef SDT
int XNaive_dot_Initialize(XNaive_dot *InstancePtr, UINTPTR BaseAddress);
XNaive_dot_Config* XNaive_dot_LookupConfig(UINTPTR BaseAddress);
#else
int XNaive_dot_Initialize(XNaive_dot *InstancePtr, u16 DeviceId);
XNaive_dot_Config* XNaive_dot_LookupConfig(u16 DeviceId);
#endif
int XNaive_dot_CfgInitialize(XNaive_dot *InstancePtr, XNaive_dot_Config *ConfigPtr);
#else
int XNaive_dot_Initialize(XNaive_dot *InstancePtr, const char* InstanceName);
int XNaive_dot_Release(XNaive_dot *InstancePtr);
#endif


void XNaive_dot_Set_rounds(XNaive_dot *InstancePtr, u32 Data);
u32 XNaive_dot_Get_rounds(XNaive_dot *InstancePtr);
void XNaive_dot_Set_data(XNaive_dot *InstancePtr, u64 Data);
u64 XNaive_dot_Get_data(XNaive_dot *InstancePtr);
void XNaive_dot_Set_weight(XNaive_dot *InstancePtr, u64 Data);
u64 XNaive_dot_Get_weight(XNaive_dot *InstancePtr);
void XNaive_dot_Set_result(XNaive_dot *InstancePtr, u64 Data);
u64 XNaive_dot_Get_result(XNaive_dot *InstancePtr);

#ifdef __cplusplus
}
#endif

#endif
