// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2025.1.1 (64-bit)
// Tool Version Limit: 2025.05
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2025 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
#ifndef __linux__

#include "xstatus.h"
#ifdef SDT
#include "xparameters.h"
#endif
#include "xsb_serial_dot.h"

extern XSb_serial_dot_Config XSb_serial_dot_ConfigTable[];

#ifdef SDT
XSb_serial_dot_Config *XSb_serial_dot_LookupConfig(UINTPTR BaseAddress) {
	XSb_serial_dot_Config *ConfigPtr = NULL;

	int Index;

	for (Index = (u32)0x0; XSb_serial_dot_ConfigTable[Index].Name != NULL; Index++) {
		if (!BaseAddress || XSb_serial_dot_ConfigTable[Index].Ctrl_bus_BaseAddress == BaseAddress) {
			ConfigPtr = &XSb_serial_dot_ConfigTable[Index];
			break;
		}
	}

	return ConfigPtr;
}

int XSb_serial_dot_Initialize(XSb_serial_dot *InstancePtr, UINTPTR BaseAddress) {
	XSb_serial_dot_Config *ConfigPtr;

	Xil_AssertNonvoid(InstancePtr != NULL);

	ConfigPtr = XSb_serial_dot_LookupConfig(BaseAddress);
	if (ConfigPtr == NULL) {
		InstancePtr->IsReady = 0;
		return (XST_DEVICE_NOT_FOUND);
	}

	return XSb_serial_dot_CfgInitialize(InstancePtr, ConfigPtr);
}
#else
XSb_serial_dot_Config *XSb_serial_dot_LookupConfig(u16 DeviceId) {
	XSb_serial_dot_Config *ConfigPtr = NULL;

	int Index;

	for (Index = 0; Index < XPAR_XSB_SERIAL_DOT_NUM_INSTANCES; Index++) {
		if (XSb_serial_dot_ConfigTable[Index].DeviceId == DeviceId) {
			ConfigPtr = &XSb_serial_dot_ConfigTable[Index];
			break;
		}
	}

	return ConfigPtr;
}

int XSb_serial_dot_Initialize(XSb_serial_dot *InstancePtr, u16 DeviceId) {
	XSb_serial_dot_Config *ConfigPtr;

	Xil_AssertNonvoid(InstancePtr != NULL);

	ConfigPtr = XSb_serial_dot_LookupConfig(DeviceId);
	if (ConfigPtr == NULL) {
		InstancePtr->IsReady = 0;
		return (XST_DEVICE_NOT_FOUND);
	}

	return XSb_serial_dot_CfgInitialize(InstancePtr, ConfigPtr);
}
#endif

#endif

