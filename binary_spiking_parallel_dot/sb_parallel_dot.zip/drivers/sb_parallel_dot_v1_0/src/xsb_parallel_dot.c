// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2025.1.1 (64-bit)
// Tool Version Limit: 2025.05
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2025 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
/***************************** Include Files *********************************/
#include "xsb_parallel_dot.h"

/************************** Function Implementation *************************/
#ifndef __linux__
int XSb_parallel_dot_CfgInitialize(XSb_parallel_dot *InstancePtr, XSb_parallel_dot_Config *ConfigPtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(ConfigPtr != NULL);

    InstancePtr->Ctrl_bus_BaseAddress = ConfigPtr->Ctrl_bus_BaseAddress;
    InstancePtr->Control_BaseAddress = ConfigPtr->Control_BaseAddress;
    InstancePtr->IsReady = XIL_COMPONENT_IS_READY;

    return XST_SUCCESS;
}
#endif

void XSb_parallel_dot_Set_rounds(XSb_parallel_dot *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XSb_parallel_dot_WriteReg(InstancePtr->Ctrl_bus_BaseAddress, XSB_PARALLEL_DOT_CTRL_BUS_ADDR_ROUNDS_DATA, Data);
}

u32 XSb_parallel_dot_Get_rounds(XSb_parallel_dot *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XSb_parallel_dot_ReadReg(InstancePtr->Ctrl_bus_BaseAddress, XSB_PARALLEL_DOT_CTRL_BUS_ADDR_ROUNDS_DATA);
    return Data;
}

void XSb_parallel_dot_Set_data(XSb_parallel_dot *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XSb_parallel_dot_WriteReg(InstancePtr->Control_BaseAddress, XSB_PARALLEL_DOT_CONTROL_ADDR_DATA_DATA, (u32)(Data));
    XSb_parallel_dot_WriteReg(InstancePtr->Control_BaseAddress, XSB_PARALLEL_DOT_CONTROL_ADDR_DATA_DATA + 4, (u32)(Data >> 32));
}

u64 XSb_parallel_dot_Get_data(XSb_parallel_dot *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XSb_parallel_dot_ReadReg(InstancePtr->Control_BaseAddress, XSB_PARALLEL_DOT_CONTROL_ADDR_DATA_DATA);
    Data += (u64)XSb_parallel_dot_ReadReg(InstancePtr->Control_BaseAddress, XSB_PARALLEL_DOT_CONTROL_ADDR_DATA_DATA + 4) << 32;
    return Data;
}

void XSb_parallel_dot_Set_weight(XSb_parallel_dot *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XSb_parallel_dot_WriteReg(InstancePtr->Control_BaseAddress, XSB_PARALLEL_DOT_CONTROL_ADDR_WEIGHT_DATA, (u32)(Data));
    XSb_parallel_dot_WriteReg(InstancePtr->Control_BaseAddress, XSB_PARALLEL_DOT_CONTROL_ADDR_WEIGHT_DATA + 4, (u32)(Data >> 32));
}

u64 XSb_parallel_dot_Get_weight(XSb_parallel_dot *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XSb_parallel_dot_ReadReg(InstancePtr->Control_BaseAddress, XSB_PARALLEL_DOT_CONTROL_ADDR_WEIGHT_DATA);
    Data += (u64)XSb_parallel_dot_ReadReg(InstancePtr->Control_BaseAddress, XSB_PARALLEL_DOT_CONTROL_ADDR_WEIGHT_DATA + 4) << 32;
    return Data;
}

void XSb_parallel_dot_Set_result(XSb_parallel_dot *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XSb_parallel_dot_WriteReg(InstancePtr->Control_BaseAddress, XSB_PARALLEL_DOT_CONTROL_ADDR_RESULT_DATA, (u32)(Data));
    XSb_parallel_dot_WriteReg(InstancePtr->Control_BaseAddress, XSB_PARALLEL_DOT_CONTROL_ADDR_RESULT_DATA + 4, (u32)(Data >> 32));
}

u64 XSb_parallel_dot_Get_result(XSb_parallel_dot *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XSb_parallel_dot_ReadReg(InstancePtr->Control_BaseAddress, XSB_PARALLEL_DOT_CONTROL_ADDR_RESULT_DATA);
    Data += (u64)XSb_parallel_dot_ReadReg(InstancePtr->Control_BaseAddress, XSB_PARALLEL_DOT_CONTROL_ADDR_RESULT_DATA + 4) << 32;
    return Data;
}

