// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2025.1.1 (64-bit)
// Tool Version Limit: 2025.05
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2025 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
// CTRL_BUS
// 0x00 : reserved
// 0x04 : reserved
// 0x08 : reserved
// 0x0c : reserved
// 0x10 : Data signal of rounds
//        bit 31~0 - rounds[31:0] (Read/Write)
// 0x14 : reserved
// (SC = Self Clear, COR = Clear on Read, TOW = Toggle on Write, COH = Clear on Handshake)

#define XNAIVE_DOT_CTRL_BUS_ADDR_ROUNDS_DATA 0x10
#define XNAIVE_DOT_CTRL_BUS_BITS_ROUNDS_DATA 32

// control
// 0x00 : reserved
// 0x04 : reserved
// 0x08 : reserved
// 0x0c : reserved
// 0x10 : Data signal of data
//        bit 31~0 - data[31:0] (Read/Write)
// 0x14 : Data signal of data
//        bit 31~0 - data[63:32] (Read/Write)
// 0x18 : reserved
// 0x1c : Data signal of weight
//        bit 31~0 - weight[31:0] (Read/Write)
// 0x20 : Data signal of weight
//        bit 31~0 - weight[63:32] (Read/Write)
// 0x24 : reserved
// 0x28 : Data signal of result
//        bit 31~0 - result[31:0] (Read/Write)
// 0x2c : Data signal of result
//        bit 31~0 - result[63:32] (Read/Write)
// 0x30 : reserved
// (SC = Self Clear, COR = Clear on Read, TOW = Toggle on Write, COH = Clear on Handshake)

#define XNAIVE_DOT_CONTROL_ADDR_DATA_DATA   0x10
#define XNAIVE_DOT_CONTROL_BITS_DATA_DATA   64
#define XNAIVE_DOT_CONTROL_ADDR_WEIGHT_DATA 0x1c
#define XNAIVE_DOT_CONTROL_BITS_WEIGHT_DATA 64
#define XNAIVE_DOT_CONTROL_ADDR_RESULT_DATA 0x28
#define XNAIVE_DOT_CONTROL_BITS_RESULT_DATA 64

